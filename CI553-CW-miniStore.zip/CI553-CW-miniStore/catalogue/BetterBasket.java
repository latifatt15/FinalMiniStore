 package catalogue;

import java.io.Serializable;
import java.util.Collections;

/**
 * Manages and sorts collection of products.
 * 
 * @author  Latifat
 * @version 1.0
 */
public class BetterBasket extends Basket 
{
	private void sortBasket() {
        Collections.sort(this, (p1, p2) -> p1.getProductNum().compareTo(p2.getProductNum()));
    }

    @Override
    public boolean add(Product pr) {
        for (Product prInList : this) {
            if (prInList.getProductNum().equals(pr.getProductNum())) {
                int quantity = pr.getQuantity() + prInList.getQuantity();
                prInList.setQuantity(quantity);
                sortBasket();  // Ensures the items are sorted
                return true;
            }
        }
        boolean added = super.add(pr);
        sortBasket();  // Ensures the items are sorted
        return added;
    }
}
